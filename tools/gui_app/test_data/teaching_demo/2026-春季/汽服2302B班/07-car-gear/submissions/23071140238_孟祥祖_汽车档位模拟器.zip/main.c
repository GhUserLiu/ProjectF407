#include "stm32f4xx_hal.h"

/* 汽车档位模拟器 - 主程序 */

// 档位定义
typedef enum {
    GEAR_P = 0,  // 驻车档
    GEAR_R = 1,  // 倒车档
    GEAR_N = 2,  // 空档
    GEAR_D = 3   // 前进档
} GearType;

GearType current_gear = GEAR_P;

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();

    while (1)
    {
        // 读取按键状态
        // 更新档位
        // 显示档位
    }
}
